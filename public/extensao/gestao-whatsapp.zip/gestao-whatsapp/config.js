// gerado por scripts/empacotar-extensao.mjs
window.GC_CONFIG = {
  "supabaseUrl": "https://nuvzzckagxmmucyqvpou.supabase.co",
  "supabaseKey": "sb_publishable_SAr0Mgjj1CTmPRYHhndLpg_hrq1iHfd",
  "servidores": [
    {
      "nome": "Produção",
      "url": "https://gerenciadorequipespeg.vercel.app"
    }
  ]
};
